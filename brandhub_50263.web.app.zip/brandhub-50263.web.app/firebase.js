var app_fireBase = {};
(function() {
    var firebaseConfig = {
        apiKey: "AIzaSyA50V6trGT8-Yintc_UYtcA05vX-F9uUXM",
        authDomain: "brandhub-50263.firebaseapp.com",
        projectId: "brandhub-50263",
        storageBucket: "brandhub-50263.appspot.com",
        messagingSenderId: "248302351575",
        appId: "1:248302351575:web:5284cb38832ccd0b282c92",
        measurementId: "G-5DMZDQBKLL"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    // firebase.analytics();

    app_fireBase = firebase;

})();